package com.cg.service;

import java.util.List;
import java.util.Scanner;

import com.cg.bean.UserDetails;
import com.cg.dao.DAOImpl;
import com.cg.dao.IDAO;

public class ServiceImpl implements IService {

	Scanner scanner = new Scanner(System.in);
	IDAO dao = new DAOImpl();

	public void createAccount(UserDetails userDetails) {
		dao.createAccount(userDetails);
	}

	public double showBalance(long accNo) {
		return dao.showBalance(accNo);
	}

	public double depositBalance(long accNo, double deposit) {
		return dao.depositBalance(accNo, deposit);
	}

	public double withdrawBalance(long accNo, double withdraw) {
		return dao.withdrawBalance(accNo, withdraw);
	}

	public double fundTransfer(long accNo, long accNo1, double balance) {
		return dao.fundTransfer(accNo, accNo1, balance);
	}

	public List<?> printTrans(long accNo) {
		return dao.printTrans(accNo);
	}

	public double validationBal(double balance) {
		while (true) {
			if (balance <= 0) {
				System.out.println("Amount is lesser than zero...");
				System.out.println("Enter the amount again: ");
				balance = scanner.nextDouble();
			} else {
				return balance;
			}
		}
	}

	public String validationName(String name) {
		if (name.matches("[A-Z][a-zA-Z]*"))
			return name;
		else
			System.out.println("Enter valid name: ");
		return name = scanner.next();
	}

	public long validationMblNo(long mblNo) {
		while (true) {
			if (String.valueOf(mblNo).length() == 10) {
				return mblNo;
			} else {
				System.out.println("Enter the valid mobile number: ");
				mblNo = scanner.nextLong();
			}
		}
	}

}
