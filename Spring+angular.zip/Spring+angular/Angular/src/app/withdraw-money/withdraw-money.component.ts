import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service';

@Component({
  selector: 'app-withdraw-money',
  templateUrl: './withdraw-money.component.html',
  styleUrls: ['./withdraw-money.component.css']
})
export class WithdrawMoneyComponent implements OnInit {
  array=[]
  user: any
  flag=false
  successflag=false
    constructor(private service: ClientService) { }
  
    ngOnInit() {
    }
  
    find(number){
      this.service.findbyid(number).subscribe(data=> {this.array=data})
      this.flag=true    
    }
    update(number, amount){
      this.service.withdraw(number,amount).subscribe(data=>{this.array=data})
      this.successflag=true
    }
}
