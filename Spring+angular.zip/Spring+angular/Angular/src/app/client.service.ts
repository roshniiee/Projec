import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";

import { Observable } from "rxjs/internal/Observable";

@Injectable({
  providedIn: 'root'
})

@Injectable({
  providedIn: 'root'
})
export class ClientService {
  
  constructor(private httpClient: HttpClient) {
  } 

baseUrl = 'http://localhost:3456/';

  public viewAll(): Observable<Account[]> {
    return this.httpClient.get<Account[]>('http://localhost:3456/viewall');
  }

  public create(account): Observable<Account[]>
  {
    // console.log(account);
    return this.httpClient.post<Account[]>("http://localhost:3456/create",account);
  }

  public findbyid(id): Observable<Account[]>
  {
    return this.httpClient.get<Account[]>("http://localhost:3456/viewbyid/"+id);
  }

  public findtransactions(id): Observable<Account[]>
  {
    return this.httpClient.get<Account[]>("http://localhost:3456/viewtransactions/"+id);
  }

  public findaccounts(number1,number2): Observable<Account[]> {
    return this.httpClient.get<Account[]>('http://localhost:3456/viewaccounts/'+number1+"/"+number2);
  } 

  public deposit(id,amount): Observable<Account[]>
  {
    return this.httpClient.put<Account[]>("http://localhost:3456/addmoney/"+id,{},{ params: {'number': amount}});
  }

  public withdraw(id,amount): Observable<Account[]>
  {
    return this.httpClient.put<Account[]>("http://localhost:3456/withdrawmoney/"+id,{},{ params: {'number': amount}});
  }

  public transfer(id1,id2,amount): Observable<Account[]>
  {
    return this.httpClient.put<Account[]>("http://localhost:3456/transfer/"+id1+"/"+id2,{},{ params: {'number': amount}});
  }
}
