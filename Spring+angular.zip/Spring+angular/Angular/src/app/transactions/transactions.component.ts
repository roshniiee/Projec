import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service';

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit {
  array=[];
  flag=false
  constructor(private service: ClientService) { }

  ngOnInit() {
  }

  setFlag(id)
  {
    this.array.splice(0,15)
    this.service.findtransactions(id).subscribe(data=>{this.array=data})
    this.flag=true
  }
}
