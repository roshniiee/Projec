import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service';
import { Account } from '../Account';

@Component({
  selector: 'app-show-all-users',
  templateUrl: './show-all-users.component.html',
  styleUrls: ['./show-all-users.component.css']
})
export class ShowAllUsersComponent implements OnInit {
  array:any
  obj=Account;
  
  constructor(private service: ClientService) {
    
   }

   
  ngOnInit() {
    this.service.viewAll().subscribe(data=>{this.array=data});
  }
  
}
