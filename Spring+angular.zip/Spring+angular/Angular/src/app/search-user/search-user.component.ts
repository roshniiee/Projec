import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service.js';

@Component({
  selector: 'app-search-user',
  templateUrl: './search-user.component.html',
  styleUrls: ['./search-user.component.css']
})
export class SearchUserComponent implements OnInit {
  array=[];
  flag=false
    constructor(private service: ClientService) { }
  
    ngOnInit() {
    }
  
    setFlag(id)
    {
      this.array.splice(0,1)
      this.service.findbyid(id).subscribe(data=>{this.array=data})
      this.flag=true
    }
}
