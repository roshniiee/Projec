export class Account
{
    accountNumber: number;
    name: String;
    phoneNumber: number;
    emailId: String;
    balance: number
}