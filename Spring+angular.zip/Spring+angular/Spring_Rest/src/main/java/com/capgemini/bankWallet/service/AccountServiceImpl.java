package com.capgemini.bankWallet.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bankWallet.dao.AccountDao;
import com.capgemini.bankWallet.dao.TransactionDao;
import com.capgemini.bankWallet.exceptions.AccountException;
import com.capgemini.bankWallet.model.Account;
import com.capgemini.bankWallet.model.Transaction;

@Service
public class AccountServiceImpl implements AccountService{
	@Autowired
	AccountDao accountDao;
	
	@Autowired
	TransactionDao transactionDao;
	
	Validator validate=new Validator();

	@Override
	public List<Account> createAccount(Account user) throws AccountException {
		// TODO Auto-generated method stub
		try
		{
			validate.validator(user);
			accountDao.save(user);
			List<Account> list=new ArrayList<Account>();
			list.add(user);
			Transaction transaction=new Transaction();
			transaction.setAccountNumber(user.getAccountNumber());
			transaction.setType("Creation");
			transaction.setDate();
			transaction.setAmount(0);
			transactionDao.save(transaction);
			return list;
		}
		catch(Exception e)
		{
			throw new AccountException(e.getMessage());
		}
	}

	@Override
	public List<Account> viewAccount(int accountNumber) throws Exception {
		// TODO Auto-generated method stub
		try
		{
			Optional<Account> user=accountDao.findById(accountNumber);
			List<Account> list=new ArrayList<Account>();
			list.add(user.get());
			return list;
		}
		catch(Exception e)
		{
			throw new AccountException(e.getMessage());
		}
	}

	@Override
	public List<Account> addMoney(int accountNumber, int amount) throws Exception {
		// TODO Auto-generated method stub
		try
		{
			validAccountNumber(accountNumber);
			Optional<Account> op=accountDao.findById(accountNumber);
			Account user=op.get();
			user.setBalance(user.getBalance()+amount);
			accountDao.save(user);
			List<Account> list=new ArrayList<Account>();
			list.add(user);
			Transaction transaction=new Transaction();
			transaction.setAccountNumber(user.getAccountNumber());
			transaction.setType("Deposit");
			transaction.setDate();
			transaction.setAmount(amount);
			transactionDao.save(transaction);
			return list;
		}
		catch(Exception e)
		{
			throw new AccountException(e.getMessage());
		}
	}

	@Override
	public List<Account> transfer(int accountNumber1, int accountNumber2, int amount) throws Exception {
		// TODO Auto-generated method stub
		try
		{
			List<Account> list= new ArrayList<Account>();
			validAccountNumber(accountNumber1);
			validAccountNumber(accountNumber2);
			if(accountNumber1==accountNumber2)
			{
				throw new AccountException("The given Accounts are same");
			}
			else
			{
				Optional<Account> op=accountDao.findById(accountNumber1);
				Account user1=op.get();
				if(user1.getBalance()>=amount)
				{
					Transaction transaction1=new Transaction();
					Transaction transaction2=new Transaction();
					op=accountDao.findById(accountNumber2);
					Account user2=op.get();
					user1.setBalance(user1.getBalance()-amount);
					user2.setBalance(user2.getBalance()+amount);
					accountDao.save(user1);
					transaction1.setAccountNumber(user1.getAccountNumber());
					transaction1.setType("Transfer-sent");
					transaction1.setDate();
					transaction1.setAmount(amount);
					transactionDao.save(transaction1);
					accountDao.save(user2);
					transaction2.setAccountNumber(user2.getAccountNumber());
					transaction2.setType("Transfer-recieved");
					transaction2.setDate();
					transaction2.setAmount(amount);
					transactionDao.save(transaction2);
					list.add(user1);
					list.add(user2);
				}
				else
				{
					throw new AccountException("Insuffecient balance in sender account");
				}
			}
			return list;			
		}
		catch(Exception e)
		{
			throw new AccountException(e.getMessage());
		}
	}

	@Override
	public List<Account> getAllAccounts() throws AccountException {
		// TODO Auto-generated method stub
		try
		{
			return accountDao.findAll();
		}
		catch(Exception e)
		{
			throw new AccountException(e.getMessage());
		}
	}
	
	public void validAccountNumber(int accountNumber) throws AccountException
	{
		try
		{
			Optional<Account> user=accountDao.findById(accountNumber);
			if(!user.isPresent())
			{
				throw new AccountException("Account:"+accountNumber+" Not Found");
			}
		}
		catch(Exception e)
		{
			throw new AccountException(e.getMessage());
		}
	}

	@Override
	public List<Account> viewAccounts(int id1, int id2) throws AccountException {
		// TODO Auto-generated method stub
		try
		{
			Optional<Account> user=accountDao.findById(id1);
			List<Account> list=new ArrayList<Account>();
			list.add(user.get());
			user=accountDao.findById(id2);
			list.add(user.get());
			return list;
		}
		catch(Exception e)
		{
			throw new AccountException(e.getMessage());
		}
	}

	@Override
	public List<Transaction> getTransactions(int accountNumber) throws Exception {
		// TODO Auto-generated method stub
		try
		{
			return transactionDao.findtrans(accountNumber);
		}
		catch(Exception e)
		{
			throw new AccountException(e.getMessage());
		}
	}

	@Override
	public List<Account> withdrawMoney(int accountNumber, int amount) throws Exception {
		// TODO Auto-generated method stub
		try
		{
			validAccountNumber(accountNumber);
			Optional<Account> op=accountDao.findById(accountNumber);
			Account user=op.get();
			user.setBalance(user.getBalance()-amount);
			accountDao.save(user);
			List<Account> list=new ArrayList<Account>();
			list.add(user);
			Transaction transaction=new Transaction();
			transaction.setAccountNumber(user.getAccountNumber());
			transaction.setType("Withdraw");
			transaction.setDate();
			transaction.setAmount(amount);
			transactionDao.save(transaction);
			return list;
		}
		catch(Exception e)
		{
			throw new AccountException(e.getMessage());
		}
	}
}
