package com.bank.service;



import java.sql.SQLException;
import java.util.HashMap;

import com.bank.bean.Banking;
import com.bank.bean.Transactions;
import com.bank.exception.BankException;

public interface BankService {

	public void addAccount(Banking bank,Transactions tran) ;
	
	public String checkBalance(int accountNo) ;
	
	public String depositMoney(int accountNumber,long amount,Transactions tran) ;
	
	public String withdrawMoney(int accountNumber, long amount,Transactions tran) ;
	
	public String getTransactionDetails(int accountNumber) ;

	public String transferMoney(int accountNumber01, long amount01, int accountNumber02,Transactions tran1,Transactions tran2) ; 
}
