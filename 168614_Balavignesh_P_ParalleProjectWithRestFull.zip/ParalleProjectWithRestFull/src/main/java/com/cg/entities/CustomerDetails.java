package com.cg.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

@Table(name = "cust")
@Entity
public class CustomerDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "a")
	@SequenceGenerator(name = "a", sequenceName = "banksq2")
	private Long accNo;
	@NotEmpty(message = "Please provide a name")
	private String name;
	@Min(value = 1, message = "Atleast initial balance should be greater than zero")
	private Double bal;
	private Long mobNo;

	public Long getAccNo() {
		return accNo;
	}

	public void setAccNo(Long accNo) {
		this.accNo = accNo;
	}

	public CustomerDetails() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getBal() {
		return bal;
	}

	public void setBal(Double bal) {
		this.bal = bal;
	}

	public Long getMobNo() {
		return mobNo;
	}

	public void setMobNo(Long mobNo) {
		this.mobNo = mobNo;
	}

	@Override
	public String toString() {
		return "UserDetails [accNo=" + accNo + ", name=" + name + ", bal= " + bal + ", mobNo=" + mobNo + "]";
	}

	public CustomerDetails(Long accNo, String pwd, String name, String address, Double bal, Long mobNo) {
		super();
		this.accNo = accNo;
		this.name = name;
		this.bal = bal;
		this.mobNo = mobNo;
	}

}
