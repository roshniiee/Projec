package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ICustomerDetails;
import com.cg.dao.ITransactionDetails;
import com.cg.entities.CustomerDetails;
import com.cg.entities.TransactionDetails;
import com.cg.exception.AccountNotFoundException;

@Service
public class ServiceImpl implements IService {

	@Autowired
	ICustomerDetails customerDao;

	@Autowired
	ITransactionDetails transactionDao;

	@Override
	public CustomerDetails createAccount(CustomerDetails customerDetails) throws AccountNotFoundException {
		if (customerDetails.getBal() == null || customerDetails.getBal() <= 0) {
			throw new AccountNotFoundException("Atleast initial balance should be more than zero");
		} else {
			customerDao.save(customerDetails);
			return customerDao.findById(customerDetails.getAccNo()).get();
		}
	}

	@Override
	public CustomerDetails accountsDetails(Long accNo) throws AccountNotFoundException {
		if (!customerDao.findById(accNo).isPresent()) {
			throw new AccountNotFoundException("Invalid account number!!!");
		} else {
			return customerDao.findById(accNo).get();
		}
	}

	@Override
	public Double showBalance(Long accNo) throws AccountNotFoundException {
		if (!customerDao.findById(accNo).isPresent()) {
			throw new AccountNotFoundException("Invalid account number!!!");
		} else {
			return customerDao.findById(accNo).get().getBal();
		}

	}

	@Override
	public Double deposit(Long accNo, Double amt) throws AccountNotFoundException {

		Optional<CustomerDetails> bank = customerDao.findById(accNo);
		if (bank.isPresent()) {
			CustomerDetails tempEntity = bank.get();
			tempEntity.setBal(bank.get().getBal() + amt);
			customerDao.save(tempEntity);
			TransactionDetails trans = new TransactionDetails(accNo, "Deposit", bank.get().getBal(),
					bank.get().getBal() + amt);
			transactionDao.save(trans);
			return showBalance(accNo);
		} else {
			throw new AccountNotFoundException("Invalid account number!!!");
		}
	}

	@Override
	public Double withdraw(Long accNo, Double amt) throws AccountNotFoundException {
		Optional<CustomerDetails> bank = customerDao.findById(accNo);
		if (bank.isPresent()) {
			if (amt > showBalance(accNo)) {
				throw new AccountNotFoundException("Low balance");
			} else {
				CustomerDetails tempEntity = bank.get();
				tempEntity.setBal(bank.get().getBal() - amt);
				customerDao.save(tempEntity);
				TransactionDetails trans = new TransactionDetails(accNo, "Withdraw", bank.get().getBal(),
						bank.get().getBal() - amt);
				transactionDao.save(trans);
				return showBalance(accNo);
			}
		} else {
			throw new AccountNotFoundException("Invalid account number!!!");
		}
	}

	@Override
	public Double fundTransfer(Long accNo, Double amt, Long accNo1) throws AccountNotFoundException {
		Optional<CustomerDetails> senderAccount = customerDao.findById(accNo);
		Optional<CustomerDetails> reciverAccount = customerDao.findById(accNo1);
		if (senderAccount.isPresent() && reciverAccount.isPresent()) {

			CustomerDetails sender = senderAccount.get();
			sender.setBal(senderAccount.get().getBal() - amt);
			customerDao.save(sender);

			CustomerDetails reciver = reciverAccount.get();
			reciver.setBal(reciverAccount.get().getBal() + amt);
			customerDao.save(reciver);

			TransactionDetails senderTrans = new TransactionDetails(accNo, "Fund transfer",
					senderAccount.get().getBal(), senderAccount.get().getBal() - amt);
			transactionDao.save(senderTrans);

			TransactionDetails reciverTrans = new TransactionDetails(accNo1, "Fund recieved",
					reciverAccount.get().getBal(), amt + reciverAccount.get().getBal());
			transactionDao.save(reciverTrans);

			return showBalance(accNo);
		} else {
			throw new AccountNotFoundException("Invalid account number!!!");
		}
	}

	@Override
	public List<TransactionDetails> printTransaction(Long accNo) {

		return transactionDao.printTransaction(accNo);
	}
}
