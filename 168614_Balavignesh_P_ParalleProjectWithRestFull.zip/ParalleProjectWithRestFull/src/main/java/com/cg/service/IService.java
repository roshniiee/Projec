package com.cg.service;

import java.util.List;

import com.cg.entities.CustomerDetails;
import com.cg.entities.TransactionDetails;
import com.cg.exception.AccountNotFoundException;

public interface IService {

	CustomerDetails createAccount(CustomerDetails customerDetails) throws AccountNotFoundException;

	CustomerDetails accountsDetails(Long accNo) throws AccountNotFoundException;

	Double showBalance(Long accNo) throws AccountNotFoundException;

	Double deposit(Long accNo, Double amt) throws AccountNotFoundException;

	Double withdraw(Long accNo, Double amt) throws AccountNotFoundException;

	Double fundTransfer(Long accNo, Double amt, Long accNo1) throws AccountNotFoundException;

	List<TransactionDetails> printTransaction(Long accNo);
}
