package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.bean.Customer;
import com.bean.Transaction;

public class DAODB {
	Connection conn;

	public DAODB() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "India123");

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();

		}

	}

	public void createAccount(Customer customer) {
		try {
			PreparedStatement p = conn.prepareStatement("insert into BankCustomerJDBC values(?,?,?,?,?)");
			p.setLong(1, customer.getAccountNo());
			p.setString(2, customer.getName());
			p.setLong(3, customer.getPhoneNo());
			p.setLong(4, customer.getAadharNo());
			p.setFloat(5, customer.getBalance());

			p.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public Customer showBalance(long accNo) {
		Customer cust = new Customer();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankCustomer where accno=" + accNo);
			while (rs.next()) {
				long accno = rs.getInt(1);
				float bal = rs.getFloat(5);
				cust.setAccountNo(accno);
				cust.setBalance(bal);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return cust;
	}

	public Customer deposit(long accno, int amount) {
		Customer cust = new Customer();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankCustomer where accno=" + accno);
			while (rs.next()) {
				long accNo = rs.getInt(1);
				float bal = rs.getFloat(5)+amount;
				cust.setAccountNo(accno);
				cust.setBalance(bal);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return cust;

		
	}

	public Customer withdraw(long accno, int amount) {
		Customer cust = new Customer();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankCustomer where accno=" + accno);
			while (rs.next()) {
				long accNo = rs.getInt(1);
				float bal = rs.getFloat(5)-amount;
				cust.setAccountNo(accno);
				cust.setBalance(bal);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return cust;


	}

	public Customer fundTransfer(long sourceAccNo, long destinationAccNo, int tfamount) {

		Customer Sourcecust = new Customer();
		Customer Desticust = new Customer();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankCustomer where accno=" + sourceAccNo);
			while (rs.next()) {
				long accNo = rs.getInt(1);
				float bal = rs.getFloat(5)-tfamount;
				Sourcecust.setAccountNo(accNo);
				Sourcecust.setBalance(bal);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankCustomer where accno=" + destinationAccNo);
			while (rs.next()) {
				long accNo = rs.getInt(1);
				float bal = rs.getFloat(5)+tfamount;
				Desticust.setAccountNo(accNo);
				Desticust.setBalance(bal);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return Sourcecust;
	}

	public void addTransaction(Transaction transaction, long accno) {
		
		
	}

}
