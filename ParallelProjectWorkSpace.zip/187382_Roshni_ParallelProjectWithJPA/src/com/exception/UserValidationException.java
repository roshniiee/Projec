package com.exception;

public class UserValidationException extends Exception {

	String s1;

	public UserValidationException(String s) {
		super(s);

	}

}
