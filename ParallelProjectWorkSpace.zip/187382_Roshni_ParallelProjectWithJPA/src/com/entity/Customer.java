package com.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BankCustomer")
public class Customer {
	@Id
	@Column(name = "accNo", length = 20)
	public long AccountNumber;
	@Column(name = "Name", length = 20)
	public String Name;
	@Column(name = "phoneNo", length = 20)
	public String PhoneNumber;
	@Column(name = "balance", length = 20)
	public long Balance;
	@Column(name = "aadharNo", length = 20)
	public String AadharNumber;
	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	@OneToOne
	public Transaction transactionId;

	public Transaction getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Transaction transactionId) {
		this.transactionId = transactionId;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}


	public long getAccountNumber() {
		return AccountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		AccountNumber = accountNumber;
	}


	public long getBalance() {
		return Balance;
	}

	public void setBalance(long balance) {
		Balance = balance;
	}

	@Override
	public String toString() {
		return "Customer [Name=" + Name + ", PhoneNumber=" + PhoneNumber + ", AccountNumber=" + AccountNumber
				+ ", Balance=" + Balance + ", AadharNumber=" + AadharNumber + "]";
	}

	public String getAadharNumber() {
		return AadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		AadharNumber = aadharNumber;
	}

	

	
}
