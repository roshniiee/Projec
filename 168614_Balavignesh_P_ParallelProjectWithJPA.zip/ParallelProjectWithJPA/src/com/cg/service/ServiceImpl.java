package com.cg.service;

import java.util.Scanner;

import com.cg.bean.TransferDetails;
import com.cg.bean.UserDetails;
import com.cg.dao.DAOImpl;
import com.cg.dao.IDAO;

public class ServiceImpl implements IService {
	Scanner scanner = new Scanner(System.in);
	IDAO d = new DAOImpl();

	@Override
	public void commitTransaction() {
		d.commitTransaction();
	}

	@Override
	public void beginTransaction() {
		d.beginTransaction();
	}

	@Override
	public void createAccount(UserDetails userDetails) {
		d.beginTransaction();
		d.createAccount(userDetails);
		d.commitTransaction();
	}

	@Override
	public UserDetails showBalance(int accNo) {
		UserDetails userDetails = d.showBalance(accNo);
		return userDetails;
	}

	@Override
	public void depositBalance(UserDetails userDetails) {
		d.beginTransaction();
		d.depositBalance(userDetails);
		d.commitTransaction();
	}

	@Override
	public void withdrawBalance(UserDetails userDetails) {
		d.beginTransaction();
		d.withdrawBalance(userDetails);
		d.commitTransaction();
	}

	@Override
	public void getTransaction(int accNo) {
		d.getTransaction(accNo);
	}

	@Override
	public void addTransferDetails(TransferDetails transferDetails) {
		d.beginTransaction();;
		d.addTransferDetails(transferDetails);
		d.commitTransaction();
	}
	
	@Override
	public double validationBal(double balance) {
		while (true) {
			if (balance <= 0) {
				System.out.println("Amount is lesser than zero...");
				System.out.println("Enter the amount again: ");
				balance = (long) scanner.nextDouble();
			} else {
				return balance;
			}
		}
	}

	@Override
	public String validationName(String name) {
		if (name.matches("[A-Z][a-zA-Z]*")) {
			return name;
		} else {
			System.out.println("Enter valid name: ");
			return name = scanner.next();
		}
	}

	@Override
	public long validationMblNo(long mblNo) {
		while (true) {
			if (String.valueOf(mblNo).length() == 10) {
				return mblNo;
			} else {
				System.out.println("Enter the valid mobile number: ");
				mblNo = scanner.nextLong();
			}
		}
	}


}