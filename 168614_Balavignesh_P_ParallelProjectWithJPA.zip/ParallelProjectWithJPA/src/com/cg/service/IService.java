package com.cg.service;

import com.cg.bean.TransferDetails;
import com.cg.bean.UserDetails;

public interface IService {
	public void commitTransaction();

	public void beginTransaction();

	void createAccount(UserDetails userDetails);

	UserDetails showBalance(int accNo);

	void withdrawBalance(UserDetails userDetails);

	void getTransaction(int accNo);

	double validationBal(double balance);

	String validationName(String name);

	long validationMblNo(long mblNo);

	void depositBalance(UserDetails userDetails);

	public void addTransferDetails(TransferDetails transferDetails);

}
