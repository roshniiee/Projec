package com.cg.dao;

import com.cg.bean.TransferDetails;
import com.cg.bean.UserDetails;

public interface IDAO {

	void createAccount(UserDetails userDetails);

	UserDetails showBalance(int accNo);

	void withdrawBalance(UserDetails userDetails);

	void getTransaction(int accNo);

	void beginTransaction();

	void commitTransaction();

	void depositBalance(UserDetails userDetails);

	void addTransferDetails(TransferDetails transferDetails);

}
