package com.cg.sprinnggJPPPAAAAAA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprinnggJpppaaaaaaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprinnggJpppaaaaaaApplication.class, args);
	}

}
