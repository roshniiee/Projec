package com.service;

import com.entity.Customer;
import com.entity.Transaction;

public interface BankService {
	Customer getByAccountNumber(long AccNo);

	void createAccount(Customer customer);

	float showBalance(long accNo);

	void deposit(Customer cust);

	void withdraw(Customer custom);

	void fundTransfer(Customer sourceCust, Customer destiCust);

	void printTransactions(long id);

	void addTransaction(Transaction transaction);

	void printDestiTransaction(int id);



}
