package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.BankDAOImpl;
import com.entity.Customer;
import com.entity.Transaction;

@Service("service")
public class BankServiceImpl implements BankService {
	@Autowired
	BankDAOImpl bankDao;

	public Customer getByAccountNumber(long AccNo) {
		Customer customer = bankDao.getByAccountNumber(AccNo);
		return customer;

	}

	public void createAccount(Customer customer) {

		bankDao.createAccount(customer);

	}

	public float showBalance(long accNo) {

		float balance = bankDao.showBalance(accNo);

		return balance;
	}

	public void deposit(Customer cust) {

		bankDao.deposit(cust);

	}

	public void withdraw(Customer custom) {

		bankDao.withdraw(custom);

	}

	public void fundTransfer(Customer sourceCust, Customer destiCust) {

		bankDao.fundTransfer(sourceCust, destiCust);

	}

	public void printTransactions(long id) {

		bankDao.printTransactions(id);

	}

	public void addTransaction(Transaction transaction) {

		bankDao.addTransaction(transaction);
	}

	public void printDestiTransaction(int id) {
		bankDao.printDestiTransaction(id);

	}

}
