package com.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Transaction")
public class Transaction {
	@Id
	public int transactionId;

	public String transactionType;
	public long sourceAccountNumber;
	public long destinationAccountNumber;
	public float Sourcebalance;
	public float Destinationbalance;
	public int amount;

	

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public long getSourceAccountNumber() {
		return sourceAccountNumber;
	}

	public void setSourceAccountNumber(long sourceAccountNumber) {
		this.sourceAccountNumber = sourceAccountNumber;
	}

	public long getDestinationAccountNumber() {
		return destinationAccountNumber;
	}

	public void setDestinationAccountNumber(long destinationAccountNumber) {
		this.destinationAccountNumber = destinationAccountNumber;
	}

	public float getSourcebalance() {
		return Sourcebalance;
	}

	public void setSourcebalance(float sourcebalance) {
		Sourcebalance = sourcebalance;
	}

	public float getDestinationbalance() {
		return Destinationbalance;
	}

	public void setDestinationbalance(float destinationbalance) {
		Destinationbalance = destinationbalance;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

}
