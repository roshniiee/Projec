package com.dao;

import com.entity.Customer;
import com.entity.Transaction;

public interface BankDAO {

	Customer getByAccountNumber(long accNo);

	Transaction getAccountNumber(long accNo);

	void createAccount(Customer customer);

	long showBalance(long accNo);

	void deposit(Customer cust);

	void withdraw(Customer custom);

	void fundTransfer(Customer sourceCust, Customer destiCust);

	void printTransactions(long id1);

	void addTransaction(Transaction transaction);

	boolean checkAccNo(long accountNumber);

	void printDestiTransaction(int id);

}
