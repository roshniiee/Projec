package com.ui;

import java.util.Random;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.Validation.UserInputValidation;
import com.entity.Customer;
import com.entity.Transaction;
import com.exception.UserValidationException;
import com.service.BankServiceImpl;

public class Main {

	public static void main(String args[]) throws UserValidationException {

		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		BankServiceImpl bankService = context.getBean("service", BankServiceImpl.class);
		int ch;
		Random random = new Random();
		Transaction transaction = new Transaction();
		char choice;

		Scanner scan = new Scanner(System.in);
		Customer customer = new Customer();
		UserInputValidation val = new UserInputValidation();

		do {
			System.out.println(
					"            MENU\n *********************\n 1. Create Account \n 2. Show Balance \n 3. Deposit \n"
							+ " 4. Withdraw \n 5. Fund Transfer \n 6. Print Transactions \n 7. Exit\n*********************");
			System.out.print("Enter your choice : ");
			ch = scan.nextInt();
			switch (ch) {
			case 1:
				System.out.println("Customer Application");
				System.out.println("---------------------------------------");

				String name;
				String phone;
				String aadhar;
				try {
					do {
						System.out.println("Enter Your Full Name:");
						name = scan.next();
					} while (!UserInputValidation.checkName(name));
				} catch (Exception e) {
					throw new UserValidationException("Enter Valid Name,Name should start with capital Letter");
				}

				customer.setName(name);
				try {
					do {
						System.out.println("Enter Your Mobile Number:");
						phone = scan.next();
					} while (!UserInputValidation.checkPhoneNumber(phone));
				} catch (Exception e) {
					throw new UserValidationException("Enter Valid Number,Number should contain 10 digits");
				}

				customer.setPhoneNumber(phone);
				try {
					do {
						System.out.println("Enter Your 12 Digit Aadhar Number:");
						aadhar = scan.next();
					} while (!UserInputValidation.checkAadharNumber(aadhar));
				} catch (Exception e) {
					throw new UserValidationException("Enter Valid Aadhar Number,Number should cotain 12 digits");
				}

				customer.setAadharNumber(aadhar);
				long accNo = random.nextInt(1000000000);
				customer.setAccountNumber(accNo);
				customer.setBalance(500);
				System.out.println("Your Initial Balance: " + customer.getBalance());
				System.out.println("Your Account Number : " + customer.getAccountNumber());
				System.out.println("Your Account is created Successfully!!");
				bankService.createAccount(customer);
				break;
			case 2:
				long accNum;
			
						System.out.println("Enter Your Account Number:");
						accNum = scan.nextLong();
				long balance = (long) bankService.showBalance(accNum);
				System.out.println("Your Balance is:" + balance);
				break;
			case 3:
				long accno;
				
						System.out.println("Enter Your Account Number:");
						accno = scan.nextLong();
				Customer cust = bankService.getByAccountNumber(accno);

				long initialBalance = cust.getBalance();
				System.out.println("enter Amount to be Deposited:");
				int amount = scan.nextInt();

				long finalBalance = initialBalance + amount;
				cust.setBalance(finalBalance);
				System.out.println("Deposited Successfully!!");
				System.out.println("Your Current balance is :" + finalBalance);
				int transId = random.nextInt(1000);

				System.out.println("Your Transaction Id is:" + transId);
				String transType = "deposit";

				transaction.setTransactionId(transId);
				transaction.setTransactionType(transType);
				transaction.setSourceAccountNumber(accno);
				transaction.setDestinationAccountNumber(accno);
				transaction.setSourcebalance(initialBalance);
				transaction.setDestinationbalance(finalBalance);
				transaction.setAmount(amount);
				cust.setTransactionId(transaction);
				bankService.addTransaction(transaction);
				bankService.deposit(cust);

				break;
			case 4:
				long acc;
				
					System.out.println("Enter Your Account Number:");
					acc= scan.nextLong();
				Customer c = bankService.getByAccountNumber(acc);
				long initialBal = c.getBalance();
				System.out.println("enter amount to be withdrawed:");
				int amt = scan.nextInt();
				long finalbal = initialBal - amt;
				c.setBalance(finalbal);
				System.out.println("Withdrawed Successfully!!");
				System.out.println("Your Current balance is :" + finalbal);
				int transid = random.nextInt(1000);
				System.out.println("Your Transaction Id is:" + transid);
				String transtype = "Withdraw";

				transaction.setTransactionId(transid);
				transaction.setTransactionType(transtype);
				transaction.setSourceAccountNumber(acc);
				transaction.setDestinationAccountNumber(acc);
				transaction.setSourcebalance(initialBal);
				transaction.setDestinationbalance(finalbal);
				transaction.setAmount(amt);
				c.setTransactionId(transaction);
				bankService.addTransaction(transaction);
				bankService.withdraw(c);
				break;
			case 5:
				long sourceAccNo;
			
					System.out.println("Enter Your SourceAccount Number:");
					sourceAccNo = scan.nextLong();
				long destinationAccNo;
				
					System.out.println("Enter Your DestinationAccount Number:");
					destinationAccNo = scan.nextLong();
			
				Customer sourceCust = bankService.getByAccountNumber(sourceAccNo);
				long SourceinitialBalance = sourceCust.getBalance();
				System.out.println("enter Amount to be transfered:");
				int tfamount = scan.nextInt();
				Customer DestiCust = bankService.getByAccountNumber(destinationAccNo);
				long DestinationinitialBalance = DestiCust.getBalance();
				long sourceFinalbal = SourceinitialBalance - tfamount;
				long destinationFinalbal = DestinationinitialBalance + tfamount;
				sourceCust.setBalance(sourceFinalbal);
				DestiCust.setBalance(destinationFinalbal);
				bankService.fundTransfer(sourceCust, DestiCust);
				System.out.println("Transfered Successfully!!");
				System.out.println("Source's Current balance is :" + sourceFinalbal);
				System.out.println("Destination's Current balance is :" + destinationFinalbal);
				int transacid = random.nextInt(1000);
				System.out.println("Your Transaction Id is:" + transacid);
				String transactype = "transfer";

				transaction.setTransactionId(transacid);
				transaction.setTransactionType(transactype);
				transaction.setSourceAccountNumber(sourceAccNo);
				transaction.setDestinationAccountNumber(destinationAccNo);
				transaction.setSourcebalance(sourceFinalbal);
				transaction.setDestinationbalance(destinationFinalbal);
				transaction.setAmount(tfamount);
				sourceCust.setTransactionId(transaction);
				DestiCust.setTransactionId(transaction);

				bankService.addTransaction(transaction);

				break;
			case 6:
				int id;
				
					System.out.println("Enter Your Account Number:");
					id = scan.nextInt();
				
			
				long id2 = transaction.getSourceAccountNumber();
			if (id2 != id) {
					bankService.printDestiTransaction(id);
				} else {
					bankService.printTransactions(id2);
				}

				break;
			case 7:
				System.out.println("--------------------------END-----------------------");
				System.exit(0);
			}
			System.out.print("Do you want to continue (y/n)...? : ");
			choice = scan.next().charAt(0);
			if (choice == 'y' || choice == 'Y')
				continue;
			else {
				System.out.println("-------------------------END------------------------");
				System.exit(0);
			}
		} while (ch != 7);
		scan.close();
	}
}