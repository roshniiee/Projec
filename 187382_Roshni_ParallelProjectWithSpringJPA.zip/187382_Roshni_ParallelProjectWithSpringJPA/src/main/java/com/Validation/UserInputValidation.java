package com.Validation;

import com.dao.BankDAOImpl;
import com.exception.UserValidationException;


public class UserInputValidation {

	static BankDAOImpl bankDAO=new BankDAOImpl();
	
	public static boolean checkName(String name) throws UserValidationException{
	
		int n = name.length();
		char[] ch = name.toCharArray();
		for (int i = 0; i < n; i++) {
			try {
				if (ch[i] > 64 && ch[i] < 122 && ch[0]>63 && ch[0]<90) {
					return true;
				} else {
					throw new UserValidationException("Invalid Name");
				}
			} 
			catch (UserValidationException E) {
				System.out.println(E);
				return false;
			}
	}
		return false;
	}
	
	
	public static boolean checkPhoneNumber(String number) throws UserValidationException
	{try {

		if(number.matches("[0-9]+") && number.length()==10)
		{
			return true;
		}
		else
		{
			throw new UserValidationException("Invalid Phone Number");
		}
	}
	catch (UserValidationException E) {
		System.out.println(E);
		
	}
return false;
}
	
	public static boolean checkAadharNumber(String aadhar) throws UserValidationException
	{try {
		if(aadhar.matches("[0-9]+") && aadhar.length()==12)
		{
			return true;
		}
		else
		{
			throw new UserValidationException("Invalid Aadhar Number");
		}
	}
	catch (UserValidationException E) {
		System.out.println(E);
		
	}
return false;
}
	
	
	
}
