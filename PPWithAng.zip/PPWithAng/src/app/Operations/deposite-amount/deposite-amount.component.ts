import { Component, OnInit, APP_INITIALIZER } from '@angular/core';
import { Router } from '@angular/router';
import { Transactions } from 'src/app/Models/Transactions';
import { MyServiceService } from 'src/app/Service/my-service.service';
import { Customer } from 'src/app/Models/Customer';

@Component({
  selector: 'app-deposite-amount',
  templateUrl: './deposite-amount.component.html',
  styleUrls: ['./deposite-amount.component.css']
})
export class DepositeAmountComponent implements OnInit {

  isLogin:boolean=true;
  customers:Customer[]=[];
  createdTransaction:Transactions;
  router:Router;

  service:MyServiceService;
  constructor(service:MyServiceService,router:Router) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
    this.router=router;
  }

  depositeAmount(data:any){
    let tid:number;
    let caccount_first=data.caccount;
    let cbalance=data.cbalance;
    var ttype:string;
    ttype="Deposite Amount"
    this.service.depositeBalance(caccount_first,cbalance);
    this.createdTransaction=new Transactions("123",data.caccount,"",data.cbalance,ttype);
    this.service.addTransaction(this.createdTransaction)
    this.router.navigate(['app-homepage']);
  }


  ngOnInit() {
    this.customers=this.service.getCustomers();
  }

}
