package com.cg.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.bean.UserDetails;
import com.cg.dao.Store;

public class Calculation implements CalculationInter {

	Scanner sc = new Scanner(System.in);
	Store s = new Store();

	@Override
	public UserDetails createAccount(UserDetails userDetails) throws ClassNotFoundException, SQLException {
		return s.createAccount(userDetails);
	}

	@Override
	public UserDetails showBalance(int accNo) throws ClassNotFoundException, SQLException {
		return s.showBalance(accNo);
	}

	@Override
	public UserDetails depositBalance(int accNo, double balance) throws ClassNotFoundException, SQLException {
		return s.depositBalance(accNo, balance);
	}

	@Override
	public UserDetails withdrawBalance(int accNo, double balance) throws ClassNotFoundException, SQLException {
		return s.withdrawBalance(accNo, balance);
	}

	@Override
	public UserDetails fundTransfer(int accNo, int accNo1, double balance) throws ClassNotFoundException, SQLException {
		return s.fundTransfer(accNo, accNo1, balance);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public ArrayList printTransaction(int accNo) throws ClassNotFoundException, SQLException {
		return s.printTransaction(accNo);
	}

	@Override
	public double validationBal(double balance) {
		while (true) {
			if (balance <= 0) {
				System.out.println("Amount is lesser than zero...");
				System.out.println("Enter the amount again: ");
				balance = (long) sc.nextDouble();
			} else {
				return balance;
			}
		}
	}

	@Override
	public String validationName(String name) {
		if (name.matches("[A-Z][a-zA-Z]*"))
			return name;
		else
			System.out.println("Enter valid name: ");
		return name = sc.next();
	}

	@Override
	public long validationMblNo(long mblNo) {
		while (true) {
			if (String.valueOf(mblNo).length() == 10) {
				return mblNo;
			} else {
				System.out.println("Enter the valid mobile number: ");
				mblNo = sc.nextLong();
			}
		}
	}

}
