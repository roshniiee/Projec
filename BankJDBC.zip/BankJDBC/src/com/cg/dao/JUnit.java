package com.cg.dao;

import static org.junit.Assert.assertTrue;

import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.bean.UserDetails;

public class JUnit {
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	Store dao = new Store();

	@Test
	public void getBalanceById() throws ClassNotFoundException, SQLException {
		UserDetails bean = dao.showBalance(12);
		// fail("Not yet implemented");
		// assertNotNull(bean);
		assertTrue(100 == bean.getBalance());
	}
}
