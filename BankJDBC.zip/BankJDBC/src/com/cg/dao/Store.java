package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.bean.UserDetails;

public class Store implements StoreInter {

	UserDetails ud = new UserDetails();
	Connection conn;

	@Override
	public UserDetails createAccount(UserDetails userDetails) throws ClassNotFoundException, SQLException {
		PreparedStatement pstmt = conn.prepareStatement("insert into userDetails values(acc_seq.nextval,?,?,?,?)");
		pstmt.setString(1, ud.getName());
		pstmt.setLong(2, ud.getMblNo());
		pstmt.setDouble(3, ud.getBalance());
		pstmt.executeUpdate();
		Statement s = conn.createStatement();
		ResultSet rs = s.executeQuery("select acc_seq.currval from dual");
		if (rs.next()) {
			userDetails.setAccNo(rs.getInt(1));
		}
		return userDetails;
	}

	@Override
	public UserDetails showBalance(int accNo) throws ClassNotFoundException, SQLException {
		UserDetails userDetails = new UserDetails();
		Connection conn = StoreDB.getConnection();
		Statement s = conn.createStatement();
		ResultSet res = s.executeQuery("select * from userDetails where accNo=" + accNo);
		if (res == null) {
			throw new AccountNotFoundException("Invalid account number...");
		} else {
			while (res.next()) {
				userDetails.setAccNo(res.getInt(1));
				userDetails.setName(res.getString(2));
				userDetails.setBalance(res.getDouble(4));
			}
		}
		return userDetails;
	}

	@Override
	public UserDetails depositBalance(int accNo, double balance) throws ClassNotFoundException, SQLException {
		UserDetails userDetails = new UserDetails();
		Connection conn = StoreDB.getConnection();
		Statement s = conn.createStatement();
		ResultSet res = s.executeQuery("select * from userDetails where accNo=" + accNo);
		if (res == null) {
			throw new AccountNotFoundException("Invalid account number...");
		} else {
			while (res.next()) {
				userDetails.setAccNo(res.getInt(1));
				userDetails.setName(res.getString(2));
				userDetails.setBalance(res.getDouble(4) + balance);
			}
			PreparedStatement p = conn.prepareStatement(
					"update userDetails set balance=" + userDetails.getBalance() + " where accNo =" + accNo);
			p.executeUpdate();
			p = conn.prepareStatement("insert into Trans_info values(trans_seq.nextval,?,?,?,?)");
			p.setInt(1, accNo);
			p.setDate(2, new Date(System.currentTimeMillis()));
			p.setDouble(3, balance);
			p.setString(4, "Deposited");
			p.executeUpdate();
		}
		return userDetails;
	}

	@Override
	public UserDetails withdrawBalance(int accNo, double balance) throws ClassNotFoundException, SQLException {
		UserDetails userDetails = new UserDetails();
		Connection conn = StoreDB.getConnection();
		Statement s = conn.createStatement();
		ResultSet res = s.executeQuery("select * from userDetails where accNo=" + accNo);
		if (res == null) {
			throw new AccountNotFoundException("Invalid account number...");
		} else {
			while (res.next()) {
				userDetails.setAccNo(res.getInt(1));
				userDetails.setName(res.getString(2));
				userDetails.setBalance(res.getDouble(4) - balance);
			}
			PreparedStatement p = conn.prepareStatement(
					"update userDetails set balance=" + userDetails.getBalance() + " where accNo =" + accNo);
			p.executeUpdate();
			p = conn.prepareStatement("insert into transferDetails values(trans_seq.nextval,?,?,?,?)");
			p.setInt(1, accNo);
			p.setDate(2, new Date(System.currentTimeMillis()));
			p.setDouble(3, balance);
			p.setString(4, "Withdraw");
			p.executeUpdate();
		}
		return userDetails;
	}

	@Override
	public UserDetails fundTransfer(int accNo, int accNo1, double balance) throws ClassNotFoundException, SQLException {

		UserDetails userDetails_2 = new UserDetails();
		Connection conn = StoreDB.getConnection();
		Statement s = conn.createStatement();
		ResultSet res = s.executeQuery("select * from userDetails where accNo=" + accNo);
		if (res == null) {
			throw new AccountNotFoundException("Invalid account number...");
		} else {
			while (res.next()) {
				userDetails_2.setAccNo(res.getInt(1));
				userDetails_2.setName(res.getString(2));
				userDetails_2.setBalance(res.getDouble(4) - balance);
			}
			PreparedStatement p = conn.prepareStatement(
					"update userDetails set amount=" + userDetails_2.getBalance() + " where accNo =" + accNo);
			p.executeUpdate();
			p = conn.prepareStatement("insert into transferDetails values(trans_seq.nextval,?,?,?,?)");
			p.setInt(1, accNo);
			p.setDate(2, new Date(System.currentTimeMillis()));
			p.setDouble(3, balance);
			p.setString(4, "Fund Transfer To " + accNo1);
			p.executeUpdate();
		}

		UserDetails userDetails_3 = new UserDetails();
		Statement s1 = conn.createStatement();
		ResultSet res1 = s1.executeQuery("select * from userDetails where accNo=" + accNo1);
		if (res1 == null) {
			throw new AccountNotFoundException("Invalid account number...");
		} else {
			while (res.next()) {
				userDetails_3.setAccNo(res.getInt(1));
				userDetails_3.setName(res.getString(2));
				userDetails_3.setBalance(res.getDouble(4) + balance);
			}
			PreparedStatement p1 = conn.prepareStatement(
					"update userDetails set amount=" + userDetails_3.getBalance() + " where accNo =" + accNo1);
			p1.executeUpdate();
			p1 = conn.prepareStatement("insert into transferDetails values(trans_seq.nextval,?,?,?,?)");
			p1.setInt(1, accNo1);
			p1.setDate(2, new Date(System.currentTimeMillis()));
			p1.setDouble(3, balance);
			p1.setString(4, "Fund Transfered From " + accNo1);
			p1.executeUpdate();
		}

		return userDetails_2;

	}

	@SuppressWarnings("rawtypes")
	@Override
	public ArrayList printTransaction(int accNo) throws ClassNotFoundException, SQLException {
		ArrayList<String> list = new ArrayList<String>();
		Connection conn = StoreDB.getConnection();
		String str = "";
		Statement s = conn.createStatement();
		ResultSet res = s.executeQuery("select * from transferDetails where accNo=" + accNo);
		while (res.next()) {
			str = String.valueOf(res.getInt(1) + "\t\t");
			str += res.getInt(2);
			str += res.getDate(3);
			str += res.getDouble(4);
			str += res.getString(5);
			list.add(str);
		}
		return list;
	}

}
