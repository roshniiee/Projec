package com.cg.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.bean.UserDetails;

public interface StoreInter {

	UserDetails createAccount(UserDetails userDetails) throws ClassNotFoundException, SQLException;

	UserDetails showBalance(int accNo) throws ClassNotFoundException, SQLException;

	UserDetails depositBalance(int accNo, double balance) throws ClassNotFoundException, SQLException;

	UserDetails withdrawBalance(int accNo, double balance) throws ClassNotFoundException, SQLException;

	UserDetails fundTransfer(int accNo, int accNo1, double balance) throws ClassNotFoundException, SQLException;

	@SuppressWarnings("rawtypes")
	ArrayList printTransaction(int accNo) throws ClassNotFoundException, SQLException;
}
