package com.cg.ui;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import com.cg.bean.UserDetails;
import com.cg.dao.AccountNotFoundException;
import com.cg.service.Calculation;

public class BankWallet {
	public int getOption(Scanner sc) {
		try {
			int option = sc.nextInt();
			return option;
		} catch (Throwable e) {
			e.printStackTrace();
			return -1;
		}
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		int option;
		Scanner sc = new Scanner(System.in);
		Calculation c = new Calculation();
		do {
			System.out.println("\n");
			System.out.println(
					"*******************************************************************************************************");
			System.out.println("\t\t\t\tXYZ BANK WALLET");
			System.out.println(
					"*******************************************************************************************************");
			System.out.println("\n1)Create Account...");
			System.out.println("2)Show Balance...");
			System.out.println("3)Deposit...");
			System.out.println("4)Withdraw...");
			System.out.println("5)Fund Transfer...");
			System.out.println("6)Print Transaction...");
			System.out.println("7)Exit...");
			System.out.println("Enter your option: ");
			option = sc.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter your name:");
				String name = c.validationName(sc.next());
				System.out.println("Enter your mobile number:");
				long mblNo = c.validationMblNo(sc.nextLong());
				Random r = new Random();// random method used for creating a random account number
				int accNo = r.nextInt(100000000);// limit
				System.out.println("Enter your initial amount: ");
				double balance = c.validationBal((sc.nextDouble()));// validating the balance which is greater than zero
																	// or not
				UserDetails userDetails = new UserDetails(name, mblNo, accNo, balance);// passing the details to service
																						// class
				UserDetails userDetails_1 = c.createAccount(userDetails);
				System.out.println("\n");
				System.out.println("------------------------------------------------------------");
				System.out.println("Thank you " + name + " Your Account is created Successully");
				System.out.println("Your Account Id " + userDetails_1.getAccNo());
				break;
			case 2:
				try {
					System.out.println("Enter your account number: ");
					accNo = sc.nextInt();
					userDetails_1 = c.showBalance(accNo);// passing the argument to service class
					System.out.println("-------------------------------------------------------------------------");
					System.out.println("Hello " + userDetails_1.getName() + "\nYour Current Account Balance is "
							+ userDetails_1.getBalance());
				} catch (AccountNotFoundException ex) {
					System.out.println(ex.getMessage());
				}
				break;
			case 3:
				try {
					System.out.println("Enter your account number: ");
					accNo = sc.nextInt();
					System.out.println("Enter your deposit amount: ");
					balance = c.validationBal(sc.nextDouble());// validating the balance which is greater than zero or
																// not
					userDetails_1 = c.depositBalance(accNo, balance);// passing the arguments to service class
					System.out.println("------------------------------------------------------------------------");
					System.out.println("Hello " + userDetails_1.getName() + " Your Amount is Deposited Succesfully");
					System.out.println("Your Current Account Balence is " + userDetails_1.getBalance());
				} catch (AccountNotFoundException ex) {
					System.out.println(ex);
				}
				break;
			case 4:
				try {
					System.out.println("Enter the account number: ");
					accNo = sc.nextInt();
					System.out.println("Enter your withdraw amount: ");
					balance = c.validationBal(sc.nextDouble());// validating the balance which is greater than zero or
																// not
					userDetails_1 = c.withdrawBalance(accNo, balance);// passing the arguments to service class
					System.out.println("------------------------------------------------------------------------");
					System.out.println("Hello " + userDetails_1.getName() + " Your Amount is Withdrawn Succesfully");
					System.out.println("Your Current Account Balence is " + userDetails_1.getBalance());
				} catch (AccountNotFoundException e) {
					System.out.println("Invalid account number...");
				} catch (Throwable ex) {
					ex.printStackTrace();
				}
				break;
			case 5:
				try {
					System.out.println("Enter your account number: ");
					accNo = sc.nextInt();
					System.out.println("Enter the account number to transfer: ");
					int accNo1 = sc.nextInt();
					System.out.println("Enter the transfer amount: ");
					balance = sc.nextDouble();
					userDetails_1 = c.fundTransfer(accNo, accNo1, balance);
					System.out.println("-----------------------------------------------------------------------------");
					System.out
							.println("Hello " + userDetails_1.getName() + " Your Amount is Transferred Succesfully\n");
					System.out.println("Your Current Account Balence is " + userDetails_1.getBalance());
				} catch (AccountNotFoundException e) {
					System.out.println("Invalid account number...");
				}
				break;
			case 6:
				System.out.println("Enter your account number: ");
				accNo = sc.nextInt();
				@SuppressWarnings("rawtypes")
				ArrayList list = c.printTransaction(accNo);
				System.out.println(
						"Transaction_Id Account_Id    Transaction_Date     Transaction_Amount 		Transaction_Type");
				System.out.println(
						"_______________________________________________________________________________________");
				for (Object i : list)
					System.out.println(i + "\n");
				System.out.println(
						"_______________________________________________________________________________________");
				break;
			case 7:
				System.out.println("Thank for using our service!!!");
				System.out.println("Regards\nXYZ BANK WALLET...");
				break;
			default:
				System.out.println("Thanks.....");
				break;
			}
		} while (option != 7);
		sc.close();
	}
}
