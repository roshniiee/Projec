package com.cg.restful.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.restful.entity.Transaction;
@Repository
public interface TransactionDao extends JpaRepository <Transaction,Long>{
	@Query("from Transaction where AccountNumber=:accn")
	List<Transaction> printTransaction(@Param("accn") long accn);
	
}
