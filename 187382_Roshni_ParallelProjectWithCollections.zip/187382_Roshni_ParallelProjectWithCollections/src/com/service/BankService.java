package com.service;

import com.dao.BankDAO;

import java.util.List;

import com.bean.Customer;
import com.bean.Transaction;

public class BankService {


	BankDAO bankDAO = new BankDAO();

	public void createAccount(Customer customer) {
		bankDAO.createAccount(customer);

	}

	public Customer showBalance(long accNo) {
		return bankDAO.showBalance(accNo);

	}

	public Customer deposit(long accno, int amount) {
		Customer cust=bankDAO.deposit(accno,amount);
		float initialBalance = cust.getBalance();
		float finalBalance = initialBalance + amount;
		cust.setBalance(finalBalance);
		cust.setTransaction("deposit");
		return cust;
	}

	public Customer withdraw(long accno, int amount) {
		Customer cust=bankDAO.withdraw(accno,amount);
		float initialBalance = cust.getBalance();
		float finalBalance = initialBalance-amount;
		cust.setBalance(finalBalance);
		cust.setTransaction("Withdraw");
		return cust;
		
		
	}

	public Customer fundTransfer(long sourceAccNo, long destinationAccNo, int tfamount) {
		return bankDAO.fundTransfer(sourceAccNo,destinationAccNo,tfamount);
		
	}


	

	public Customer printTransactions(long accn) {
		return bankDAO.printTransaction(accn);
		
		
	}


}
