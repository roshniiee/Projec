package com.cg.ppspringrestful.entity;
	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.SequenceGenerator;
	import javax.persistence.Table;
	@Entity
	@Table(name="TransRestFul")
	public class Transaction {
		@Id
		@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="transactionID")
	    @SequenceGenerator(name="transactionID", initialValue=100, allocationSize=1, sequenceName = "transaction_Seq")
	    @Column(name="Transaction_Seq", updatable=false, nullable=false)
		private int transId;
		private String transType;
		private long accountNum;
		private double amount;
		public int getTransId() {
			return transId;
		}
		public void setTransId(int transId) {
			this.transId = transId;
		}
		public String getTransType() {
			return transType;
		}
		public void setTransType(String transType) {
			this.transType = transType;
		}
		public long getAccountNum() {
			return accountNum;
		}
		public void setAccountNum(long accountNum) {
			this.accountNum = accountNum;
		}
		public double getAmount() {
			return amount;
		}
		public void setAmount(double amount) {
			this.amount = amount;
		}
		@Override
		public String toString() {
			return "Transaction [transId=" + transId + ", transType=" + transType + ", accountNum=" + accountNum
					+ ", amount=" + amount + "]";
		}
		
	}

