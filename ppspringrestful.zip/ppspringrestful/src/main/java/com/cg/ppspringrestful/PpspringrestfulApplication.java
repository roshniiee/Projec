package com.cg.ppspringrestful;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PpspringrestfulApplication {

	public static void main(String[] args) {
		SpringApplication.run(PpspringrestfulApplication.class, args);
	}

}
