package com.cg.ppspringrestful.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.ppspringrestful.entity.Bank;

@Repository
public interface BankDao extends JpaRepository<Bank, Long> {

}
