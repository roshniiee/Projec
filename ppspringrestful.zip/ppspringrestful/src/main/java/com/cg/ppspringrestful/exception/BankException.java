package com.cg.ppspringrestful.exception;

public class BankException extends Exception{
	
		public BankException() {
			
		}
		public BankException(String msg) {
			super(msg);
		}

	}

