package com.cg.ppspringrestful.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.ppspringrestful.dao.BankDao;
import com.cg.ppspringrestful.dao.TransactionDao;
import com.cg.ppspringrestful.entity.Bank;
import com.cg.ppspringrestful.entity.Transaction;

@Service
public class BankServiceImpl implements BankService {
	
	@Autowired
	BankDao bankDao;
	@Autowired
	TransactionDao transactionDao;

	@Override
	public List<Bank> CreateAccount(Bank bank) {
		bankDao.save(bank);
		return bankDao.findAll();
	}

	@Override
	public Bank ShowDetails(long accountNo) {
		 @SuppressWarnings("unchecked")
		Bank details = bankDao.findById(accountNo).get();
	    return details;
	}

	@Override
	public Optional<Bank> Deposite(long accNo, double amount) {
		Bank b = bankDao.findById(accNo).get();
		Transaction transaction = new Transaction();
		float initialBalance = b.getBalance();
		float finalBalance = (float) (initialBalance + amount);
		b.setBalance(finalBalance);
		transaction.setTransType("Deposit");
		transaction.setAccountNum(accNo);
		transaction.setAmount(amount);
		transactionDao.save(transaction);
		bankDao.save(b);
		return bankDao.findById(accNo);
	}

	@Override
	public Optional<Bank> Withdraw(long accno, double amount) {
		Bank b = bankDao.findById(accno).get();
		Transaction transaction = new Transaction();
		float initialBalance = b.getBalance();
		float finalBalance = (float) (initialBalance - amount);
		b.setBalance(finalBalance);
		transaction.setAccountNum(accno);
		transaction.setAmount(amount);
		transaction.setTransType("Withdraw");
		transactionDao.save(transaction);
		bankDao.save(b);
		return bankDao.findById(accno);
	}

	@Override
	public List<Bank> FundTransfer(long sourceaccno, long destinationaccno, double amount) {
		Bank sourceCust = bankDao.findById(sourceaccno).get();
		Transaction transaction=new Transaction();
		Transaction destitransaction=new Transaction();
		Bank destiCust = bankDao.findById(destinationaccno).get();
		float sourceInitialbal = sourceCust.getBalance();
		float destiInitialbal = destiCust.getBalance();
		float sourceFinalBal = (float) (sourceInitialbal - amount);
		float destiFinalBal = (float) (destiInitialbal + amount);
		sourceCust.setBalance(sourceFinalBal);
		destiCust.setBalance(destiFinalBal);
		transaction.setAccountNum(sourceaccno);
		transaction.setAmount(amount);
		transaction.setTransType("Transfer");
		transactionDao.save(transaction);
		destitransaction.setAccountNum(destinationaccno);
		destitransaction.setTransType("transfer");
		destitransaction.setAmount(amount);
		transactionDao.save(destitransaction);
		return bankDao.findAll();

	}

	@Override
	public List<Transaction> Statement(long accnum) {
		return transactionDao.Statement(accnum);
	}
	
	

}
