package com.cg.ppspringrestful.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ppspringrestful.entity.Bank;
import com.cg.ppspringrestful.entity.Transaction;
import com.cg.ppspringrestful.service.BankService;

@RestController
public class BankController {
	@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Customer with this Id is not found")
	@ExceptionHandler({Exception.class})
	public void handleException() {
		
	}
	@Autowired
	BankService bankService;
	
	
	@PostMapping("/createaccount")
	public List<Bank> CreateAccount(@RequestBody Bank bank){
	return bankService.CreateAccount(bank);
	}
	
	@GetMapping("/showdetails/{accountNo}")
	public Bank ShowDetails(@PathVariable long accountNo) {
		return bankService.ShowDetails(accountNo);
	}
	
	@PutMapping("/deposite/{accNo}/{amount}")
	public Optional<Bank> Deposite(@PathVariable long accNo, @PathVariable double amount){
		return bankService.Deposite(accNo, amount);
	}
	
	@PutMapping("/withdraw/{accno}/{amount}")
	public Optional<Bank> Withdraw(@PathVariable long accno, @PathVariable double amount){
		return bankService.Withdraw(accno, amount);
	}
	
	@PutMapping("/fundtransfer/{sourceaccno}/{destinationaccno}/{amount}")
	public List<Bank> FundTransfer(@PathVariable long sourceaccno,@PathVariable long destinationaccno, @PathVariable double amount){
		return bankService.FundTransfer(sourceaccno, destinationaccno, amount);
	}
	
	@GetMapping("/statement/{accnum}")
	public List<Transaction> Statement(@PathVariable long accnum){
		return bankService.Statement(accnum);
	}
}