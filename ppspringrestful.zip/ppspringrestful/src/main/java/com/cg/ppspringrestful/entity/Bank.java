package com.cg.ppspringrestful.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

@Entity
public class Bank {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="AccountId")
    @SequenceGenerator(name="AccountId", initialValue=1000, allocationSize=1, sequenceName = "bankAccountNo")
    @Column(name="BankAccountNo", updatable=false, nullable=false)
	private long accNo;
	private String name;
	private long phoneNo;
	private float balance;
	private long aadharNo;
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	public long getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(long aadharNo) {
		this.aadharNo = aadharNo;
	}
	@Override
	public String toString() {
		return "Bank [accNo=" + accNo + ", name=" + name + ", phoneNo=" + phoneNo + ", balance=" + balance
				+ ", aadharNo=" + aadharNo + "]";
	}


}
