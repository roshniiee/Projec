package com.cg.ppspringrestful.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.cg.ppspringrestful.entity.Transaction;

public interface TransactionDao extends JpaRepository<Transaction, Long> {

	@Query("from Transaction where accountNum=:accn")
	List<Transaction> Statement(@Param("accn") long acc);

	
}
