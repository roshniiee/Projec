package com.cg.ppspringrestful.service;

import java.util.List;
import java.util.Optional;

import com.cg.ppspringrestful.entity.Bank;
import com.cg.ppspringrestful.entity.Transaction;

public interface BankService {

	public List<Bank> CreateAccount(Bank bank);

	public Bank ShowDetails(long accountNo);

	public Optional<Bank> Deposite(long accNo, double amount);

	public Optional<Bank> Withdraw(long accno, double amount);

	public List<Bank> FundTransfer(long sourceaccno, long destinationaccno, double amount);

	public List<Transaction> Statement(long accnum);

}
