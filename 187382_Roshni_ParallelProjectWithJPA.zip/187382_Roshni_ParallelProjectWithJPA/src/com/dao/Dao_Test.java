package com.dao;

import static org.junit.jupiter.api.Assertions.*;

import javax.persistence.EntityManager;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import com.entity.Customer;

public class Dao_Test {

	EntityManager entityManager;
	UtilJava jUtil=new UtilJava();
	Customer customer;

	@Test
	public void getBalance() {
		entityManager = jUtil.getEntityManager();
		entityManager.getTransaction().begin();
		Customer customer = entityManager.find(Customer.class, new Long(830081125));
		entityManager.getTransaction().commit();
		long bal = customer.getBalance();
		long expected = 600;
	Assert.assertEquals(expected, bal);
	}
}