package com.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import com.entity.Customer;
import com.entity.Transaction;

public class BankDAOImpl implements BankDAO{
	Customer customer = new Customer();
	Transaction transaction = new Transaction();
	EntityManager entity = UtilJava.getEntityManager();
@Override
	public Customer getByAccountNumber(long accNo) {
		customer = entity.find(Customer.class, accNo);
		return customer;
	}
@Override
	public Transaction getAccountNumber(long accNo) {
		Transaction trans = entity.find(Transaction.class, accNo);
		return trans;
	}
@Override
	public void createAccount(Customer customer) {
		entity.persist(customer);

	}
@Override
	public long showBalance(long accNo) {

		customer = entity.find(Customer.class, accNo);

		return customer.getBalance();

	}
@Override
	public void deposit(Customer cust) {
		entity.merge(cust);

	}
@Override
	public void withdraw(Customer custom) {
		entity.merge(custom);
	}
@Override
	public void fundTransfer(Customer sourceCust, Customer destiCust) {
		entity.merge(sourceCust);
		entity.merge(destiCust);
	}
@Override
	public void printTransactions(long id1) {

		System.out.println("Transafered to");
		Query q = entity.createQuery("select t from Transaction t where SourceAccountNumber=:tid");
		q.setParameter("tid", id1);
		List<Transaction> l = q.getResultList();

		System.out.println("------------------------------------------------------------------");
		for (Transaction tdetails : l) {
			System.out.println("Transaction id:" + tdetails.getTransactionId() + "\n" + "Transaction Type:"
					+ tdetails.getTransactionType() + "\n" + "Amount:" + tdetails.getAmount() + "\n" + "SourceBalance :"
					+ tdetails.getSourcebalance() + "\n" + "DestinationBalance: " + tdetails.getDestinationbalance()
					+ "\n" + "To(accNo) " + tdetails.getDestinationAccountNumber() + "\n" + "From(accNo) "
					+ tdetails.getSourceAccountNumber() + "\n");
		}

	}
@Override
	public void printDestiTransaction(int id) {

		Query q1 = entity.createQuery("select t1 from Transaction t1 where destinationaccountNumber=:did");
		q1.setParameter("did", id);
		List<Transaction> l1 = q1.getResultList();

		System.out.println("------------------------------------------------------------------");
		for (Transaction tdetails1 : l1) {
			System.out.println("Transaction id:" + tdetails1.getTransactionId() + "\n" + "Transaction Type:"
					+ tdetails1.getTransactionType() + "\n" + "Amount:" + tdetails1.getAmount() + "\n"
					+ "SourceBalance :" + tdetails1.getSourcebalance() + "\n" + "DestinationBalance: "
					+ tdetails1.getDestinationbalance() + "\n" + "To(accNo) " + tdetails1.getDestinationAccountNumber()
					+ "\n" + "From(accNo) " + tdetails1.getSourceAccountNumber() + "\n");
		}

	}
@Override
	public void addTransaction(Transaction transaction) {
		entity.persist(transaction);

	}
@Override
	public void beginTransaction() {
		entity.getTransaction().begin();

	}
@Override
	public void commitTransaction() {
		entity.getTransaction().commit();

	}
@Override
	public boolean checkAccNo(long accountNumber) {
		Customer cust=entity.find(Customer.class, accountNumber);
		if(cust==null)
		return false;
		else
			return true;
	}

}
