package com.service;

import com.dao.BankDAOImpl;
import com.entity.Customer;
import com.entity.Transaction;

public class BankServiceImpl implements BankService{
	BankDAOImpl bankDao = new BankDAOImpl();
	@Override
	public Customer getByAccountNumber(long AccNo) {
		Customer customer = bankDao.getByAccountNumber(AccNo);
		return customer;

	}

	@Override
	public void createAccount(Customer customer) {
		bankDao.beginTransaction();
		bankDao.createAccount(customer);
		bankDao.commitTransaction();
	}
	@Override
	public float showBalance(long accNo) {
		bankDao.beginTransaction();
		float balance = bankDao.showBalance(accNo);
		bankDao.commitTransaction();
		return balance;
	}
	@Override
	public void deposit(Customer cust) {
		bankDao.beginTransaction();
		bankDao.deposit(cust);
		bankDao.commitTransaction();

	}
	@Override
	public void withdraw(Customer custom) {
		bankDao.beginTransaction();
		bankDao.withdraw(custom);
		bankDao.commitTransaction();
	}
	@Override
	public void fundTransfer(Customer sourceCust, Customer destiCust) {
		bankDao.beginTransaction();
		bankDao.fundTransfer(sourceCust,destiCust);
		bankDao.commitTransaction();
	}
	@Override
	public void printTransactions(long id) {
		bankDao.beginTransaction();
		bankDao.printTransactions(id);
		bankDao.commitTransaction();
	}
@Override
	public void addTransaction(Transaction transaction) {
		
		bankDao.beginTransaction();
		bankDao.addTransaction(transaction);
		bankDao.commitTransaction();
	}

@Override
	public void printDestiTransaction(int id) {
		bankDao.beginTransaction();
		bankDao.printDestiTransaction(id);
		bankDao.commitTransaction();
		
	}


	
	}

