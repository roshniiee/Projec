package com.ui;

import java.util.Random;
import java.util.Scanner;

import com.Validation.UserInputValidation;

import com.entity.Customer;
import com.entity.Transaction;
import com.exception.UserValidationException;
import com.service.BankServiceImpl;

import oracle.net.aso.s;

public class User {

	Random random = new Random();
	BankServiceImpl bankService = new BankServiceImpl();
	Scanner scan = new Scanner(System.in);
	UserInputValidation val = new UserInputValidation();
	public void createAccount() throws UserValidationException {
		Customer customer = new Customer();
		
		System.out.println("Customer Application");
		System.out.println("---------------------------------------");

		String name;
		String phone;
		String aadhar;
		try {
			do {
				System.out.println("Enter Your Full Name:");
				name = scan.next();
			} while (!val.checkName(name));
		} catch (Exception e) {
			throw new UserValidationException("Enter Valid Name,Name should start with capital Letter");
		}

		customer.setName(name);
		try {
			do {
				System.out.println("Enter Your Mobile Number:");
				phone = scan.next();
			} while (!val.checkPhoneNumber(phone));
		} catch (Exception e) {
			throw new UserValidationException("Enter Valid Number,Number should contain 10 digits");
		}

		customer.setPhoneNumber(phone);
		try {
			do {
				System.out.println("Enter Your 12 Digit Aadhar Number:");
				aadhar = scan.next();
			}while(!val.checkAadharNumber(aadhar));
		}
		catch (Exception e) {
			throw new UserValidationException("Enter Valid Aadhar Number,Number should cotain 12 digits");
		}
		
		customer.setAadharNumber(aadhar);
		long accNo = random.nextInt(1000000000);
		customer.setAccountNumber(accNo);
		customer.setBalance(500);
		System.out.println("Your Initial Balance: " + customer.getBalance());
		System.out.println("Your Account Number : " + customer.getAccountNumber());
		System.out.println("Your Account is created Successfully!!");
		bankService.createAccount(customer);

	}

	public void showBalance() throws UserValidationException  {
		long accNo;
		try {
		do {
			System.out.println("Enter Your Account Number:");
			accNo = scan.nextLong();
		}while(!val.checkAccNo(accNo));
		
		}
		catch (Exception e) {
			throw new UserValidationException("Enter Valid Account Number");
		}
	
		long balance = (long) bankService.showBalance(accNo);
		System.out.println("Your Balance is:" + balance);
	}

	public void deposit() throws UserValidationException {
		Transaction transaction = new Transaction();
		long accno;
		try {
		do {
			System.out.println("Enter Your Account Number:");
			accno = scan.nextLong();
		}while(!val.checkAccNo(accno));
		
		}
		catch (Exception e) {
			throw new UserValidationException("Enter Valid Account Number");
		}
	
		Customer cust = bankService.getByAccountNumber(accno);

		long initialBalance = cust.getBalance();
		System.out.println("enter Amount to be Deposited:");
		int amount = scan.nextInt();

		long finalBalance = initialBalance + amount;
		cust.setBalance(finalBalance);
		System.out.println("Deposited Successfully!!");
		System.out.println("Your Current balance is :" + finalBalance);
		int transId = random.nextInt(1000);

		System.out.println("Your Transaction Id is:" + transId);
		String transType = "deposit";

		transaction.setTransactionId(transId);
		transaction.setTransactionType(transType);
		transaction.setSourceAccountNumber(accno);
		transaction.setDestinationAccountNumber(accno);
		transaction.setSourcebalance(initialBalance);
		transaction.setDestinationbalance(finalBalance);
		transaction.setAmount(amount);
		cust.setTransactionId(transaction);
		bankService.addTransaction(transaction);
		bankService.deposit(cust);

	}

	public void withdraw() throws UserValidationException {
		Transaction transaction = new Transaction();
		long acc;
		try {
		do {
			System.out.println("Enter Your Account Number:");
			acc= scan.nextLong();
		}while(!val.checkAccNo(acc));
		
		}
		catch (Exception e) {
			throw new UserValidationException("Enter Valid Account Number");
		}
	
		Customer c = bankService.getByAccountNumber(acc);
		long initialBal = c.getBalance();
		System.out.println("enter amount to be withdrawed:");
		int amt = scan.nextInt();
		long finalbal = initialBal - amt;
		c.setBalance(finalbal);
		System.out.println("Withdrawed Successfully!!");
		System.out.println("Your Current balance is :" + finalbal);
		int transid = random.nextInt(1000);
		System.out.println("Your Transaction Id is:" + transid);
		String transtype = "Withdraw";

		transaction.setTransactionId(transid);
		transaction.setTransactionType(transtype);
		transaction.setSourceAccountNumber(acc);
		transaction.setDestinationAccountNumber(acc);
		transaction.setSourcebalance(initialBal);
		transaction.setDestinationbalance(finalbal);
		transaction.setAmount(amt);
		c.setTransactionId(transaction);
		bankService.addTransaction(transaction);
		bankService.withdraw(c);
	}

	public void fundTransfer() throws UserValidationException {
		Transaction transaction = new Transaction();
		long sourceAccNo;
		try {
		do {
			System.out.println("Enter Your SourceAccount Number:");
			sourceAccNo = scan.nextLong();
		}while(!val.checkAccNo(sourceAccNo));
		
		}
		catch (Exception e) {
			throw new UserValidationException("Enter Valid SourceAccount Number");
		}
		long destinationAccNo;
		try {
		do {
			System.out.println("Enter Your DestinationAccount Number:");
			destinationAccNo = scan.nextLong();
		}while(!val.checkAccNo(destinationAccNo));
		
		}
		catch (Exception e) {
			throw new UserValidationException("Enter Valid DestinationAccount Number");
		}
	
		Customer sourceCust = bankService.getByAccountNumber(sourceAccNo);
		long SourceinitialBalance = sourceCust.getBalance();
		System.out.println("enter Amount to be transfered:");
		int tfamount = scan.nextInt();
		Customer DestiCust = bankService.getByAccountNumber(destinationAccNo);
		long DestinationinitialBalance = DestiCust.getBalance();
		long sourceFinalbal = SourceinitialBalance - tfamount;
		long destinationFinalbal = DestinationinitialBalance + tfamount;
		sourceCust.setBalance(sourceFinalbal);
		DestiCust.setBalance(destinationFinalbal);
		bankService.fundTransfer(sourceCust, DestiCust);
		System.out.println("Transfered Successfully!!");
		System.out.println("Source's Current balance is :" + sourceFinalbal);
		System.out.println("Destination's Current balance is :" + destinationFinalbal);
		int transid = random.nextInt(1000);
		System.out.println("Your Transaction Id is:" + transid);
		String transtype = "transfer";

		transaction.setTransactionId(transid);
		transaction.setTransactionType(transtype);
		transaction.setSourceAccountNumber(sourceAccNo);
		transaction.setDestinationAccountNumber(destinationAccNo);
		transaction.setSourcebalance(sourceFinalbal);
		transaction.setDestinationbalance(destinationFinalbal);
		transaction.setAmount(tfamount);
		sourceCust.setTransactionId(transaction);
		DestiCust.setTransactionId(transaction);

		bankService.addTransaction(transaction);

	}

	public void printTransactions() throws UserValidationException {
		Transaction transaction = new Transaction();
		int id;
		try {
		do {
			System.out.println("Enter Your Account Number:");
			id = scan.nextInt();
		}while(!val.checkAccNo(id));
		
		}
		catch (Exception e) {
			throw new UserValidationException("Enter Valid Account Number");
		}
	
		long id2 = transaction.getSourceAccountNumber();
	if (id2 != id) {
			bankService.printDestiTransaction(id);
		} else {
			bankService.printTransactions(id2);
		}

	}

}
