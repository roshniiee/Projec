package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.bean.Customer;
import com.bean.Transaction;

public class DAODB {
	Connection conn;

	public DAODB() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "India123");

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();

		}

	}

	public void createAccount(Customer customer) {
		try {
			PreparedStatement p = conn.prepareStatement("insert into BankCustomerJDBC values(?,?,?,?,?)");
			p.setLong(1, customer.getAccountNo());
			p.setString(2, customer.getName());
			p.setLong(3, customer.getPhoneNo());
			p.setLong(4, customer.getAadharNo());
			p.setFloat(5, customer.getBalance());

			p.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public Customer showBalance(long accNo) {
		Customer cust = new Customer();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankCustomerJDBC where accno=" + accNo);
			while (rs.next()) {
				long accno = rs.getInt(1);
				float bal = rs.getFloat(5);
				cust.setAccountNo(accno);
				cust.setBalance(bal);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return cust;
	}

	public Customer deposit(long accno, int amount) {
		Customer cust = new Customer();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankCustomerJDBC where accno=" + accno);
			while (rs.next()) {
				long accNo = rs.getInt(1);
				float bal = rs.getFloat(5) + amount;
				cust.setAccountNo(accno);
				cust.setBalance(bal);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return cust;

	}

	public Customer withdraw(long accno, int amount) {
		Customer cust = new Customer();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankCustomerJDBC where accno=" + accno);
			while (rs.next()) {
				long accNo = rs.getInt(1);
				float bal = rs.getFloat(5) - amount;
				cust.setAccountNo(accno);
				cust.setBalance(bal);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return cust;

	}

	public Customer fundTransfer(long sourceAccNo, long destinationAccNo, int tfamount) {

		Customer Sourcecust = new Customer();
		Customer Desticust = new Customer();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankCustomerJDBC where accno=" + sourceAccNo);
			while (rs.next()) {
				long accNo = rs.getInt(1);
				float bal = rs.getFloat(5) - tfamount;
				Sourcecust.setAccountNo(accNo);
				Sourcecust.setBalance(bal);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return Sourcecust;
	}

	public Transaction printSourceTransaction(long acc) {
		Transaction trans = new Transaction();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from TransactionJDBC where sourceaccno=" + acc);
			while (rs.next()) {
				int transid = rs.getInt(1);
				String type = rs.getString(2);
				long sourceacc = rs.getLong(3);
				long destiacc = rs.getLong(4);
				int amount = rs.getInt(5);
				trans.setTransactionId(transid);
				trans.setTransactionType(type);
				trans.setSourceAccountNumber(sourceacc);
				trans.setDestinationAccountNumber(destiacc);
				trans.setAmount(amount);
			}
		

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return trans;
	}

	public void addTransaction(Transaction transaction) {
		try {
			PreparedStatement p = conn.prepareStatement("insert into TransactionJDBC values(?,?,?,?,?)");
			p.setInt(1, transaction.getTransactionId());
			p.setString(2, transaction.getTransactionType());
			p.setLong(3, transaction.getSourceAccountNumber());
			p.setLong(4, transaction.getDestinationAccountNumber());
			p.setInt(5, transaction.getAmount());

			p.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();
		}

	}
}
